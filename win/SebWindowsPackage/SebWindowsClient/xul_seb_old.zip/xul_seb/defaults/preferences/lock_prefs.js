//TODO
//pref("general.config.filename", "mozilla.cfg");

//workaround
lock_pref("app.update.auto", false);
lock_pref("app.update.enabled", false);
lock_pref("browser.startup.homepage_override.mstone", "ignore");
lock_pref("extensions.update.enabled", false);